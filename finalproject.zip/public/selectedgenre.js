function selectGenre(id){
    $("#genre-selector").val(id);
}