function selectAuthor(id){
    $("#author-selector").val(id);
}