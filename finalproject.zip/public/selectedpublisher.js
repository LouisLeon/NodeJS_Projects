function selectPublisher(id){
    $("#publisher-selector").val(id);
}